using NUnit.Framework;

namespace UnityEditor.Experimental.U2D.Common.Tests
{
    internal class Common2DTests
    {
        [Test]
        public void PlaceHolderTest()
        {
            Assert.Pass("This is a placeholder to ensure we have at least one editor test.");
        }
    }
}

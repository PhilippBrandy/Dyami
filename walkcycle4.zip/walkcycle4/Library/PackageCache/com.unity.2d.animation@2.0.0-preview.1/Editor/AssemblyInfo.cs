using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Animation.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.PsdImporter.Editor")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]

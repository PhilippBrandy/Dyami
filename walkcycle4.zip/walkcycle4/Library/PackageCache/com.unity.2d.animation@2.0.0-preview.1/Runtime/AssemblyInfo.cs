using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Animation.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.PsdImporter.Editor")]

using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("com.unity.2d.psdimporter.EditorTests")]
